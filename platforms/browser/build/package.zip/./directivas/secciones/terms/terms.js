geobarApp.directive('terms', function() {
  return {
    restrict: 'E',
    templateUrl: 'directivas/secciones/terms/terms.html'


  };
});